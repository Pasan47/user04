import React from "react";

const AddUser = () => {
  return <div>AddUser</div>;
};

export default AddUser;
