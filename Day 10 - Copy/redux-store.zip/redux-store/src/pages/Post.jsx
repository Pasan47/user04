import React from "react";

function Post() {
  return <div>Post</div>;
}

export default Post;
